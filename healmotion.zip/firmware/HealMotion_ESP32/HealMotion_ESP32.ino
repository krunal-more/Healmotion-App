#include <WiFi.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <MAX30105.h>
#include "heartRate.h"
#include "spo2_algorithm.h"
#include <Adafruit_MLX90614.h>

const char* WIFI_SSID = "HealMotion_ESP32";
const char* WIFI_PASSWORD = "healmotion123";

const uint8_t I2C_SDA = 21;
const uint8_t I2C_SCL = 22;
const uint8_t BATTERY_ADC_PIN = 34;

const uint8_t CONV_RPWM_PIN = 25;
const uint8_t CONV_LPWM_PIN = 26;
const uint8_t CONV_REN_PIN = 27;
const uint8_t CONV_LEN_PIN = 32;

const bool CONVERSION_MOTOR_ENABLED = true;
const bool CONVERSION_MOTOR_INVERTED = false;
const uint16_t COMMAND_TIMEOUT_MS = 750;
const uint16_t TELEMETRY_INTERVAL_MS = 1000;
const uint8_t PWM_RESOLUTION_BITS = 8;
const uint32_t PWM_FREQUENCY = 20000;
const uint8_t PWM_CHANNEL_R = 0;
const uint8_t PWM_CHANNEL_L = 1;

const float ADC_REFERENCE = 3.3;
const float ADC_MAX = 4095.0;
const float BATTERY_R1 = 100000.0;
const float BATTERY_R2 = 10000.0;
const float BATTERY_CALIBRATION = 1.00;

WebSocketsServer webSocket(80);
MAX30105 max30102;
Adafruit_MLX90614 mlx = Adafruit_MLX90614();

bool maxReady = false;
bool mlxReady = false;
bool emergencyActive = false;
String conversionState = "IDLE";
String conversionPosition = "UNKNOWN";
int conversionSpeedPercent = 45;
unsigned long lastCommandTime = 0;
unsigned long lastTelemetryTime = 0;

void setup() {
  Serial.begin(115200);
  initializeMotorPins();
  conversionMotorStop();

  Wire.begin(I2C_SDA, I2C_SCL);
  maxReady = max30102.begin(Wire, I2C_SPEED_FAST);
  if (maxReady) {
    max30102.setup();
    max30102.setPulseAmplitudeRed(0x2A);
    max30102.setPulseAmplitudeIR(0x2A);
  }
  mlxReady = mlx.begin(0x5A, &Wire);

  WiFi.mode(WIFI_AP);
  WiFi.softAP(WIFI_SSID, WIFI_PASSWORD);

  webSocket.begin();
  webSocket.onEvent(onWebSocketEvent);

  Serial.print("HealMotion AP IP: ");
  Serial.println(WiFi.softAPIP());
}

void loop() {
  webSocket.loop();
  enforceCommandWatchdog();

  if (millis() - lastTelemetryTime >= TELEMETRY_INTERVAL_MS) {
    lastTelemetryTime = millis();
    sendTelemetry();
  }
}

void initializeMotorPins() {
  pinMode(CONV_REN_PIN, OUTPUT);
  pinMode(CONV_LEN_PIN, OUTPUT);
  digitalWrite(CONV_REN_PIN, LOW);
  digitalWrite(CONV_LEN_PIN, LOW);

  ledcSetup(PWM_CHANNEL_R, PWM_FREQUENCY, PWM_RESOLUTION_BITS);
  ledcSetup(PWM_CHANNEL_L, PWM_FREQUENCY, PWM_RESOLUTION_BITS);
  ledcAttachPin(CONV_RPWM_PIN, PWM_CHANNEL_R);
  ledcAttachPin(CONV_LPWM_PIN, PWM_CHANNEL_L);
  ledcWrite(PWM_CHANNEL_R, 0);
  ledcWrite(PWM_CHANNEL_L, 0);
}

void onWebSocketEvent(uint8_t client, WStype_t type, uint8_t* payload, size_t length) {
  if (type == WStype_DISCONNECTED) {
    conversionMotorStop();
    conversionState = "STOPPED";
    return;
  }

  if (type == WStype_TEXT) {
    handleCommand(client, payload, length);
  }
}

void handleCommand(uint8_t client, uint8_t* payload, size_t length) {
  StaticJsonDocument<256> doc;
  DeserializationError error = deserializeJson(doc, payload, length);
  if (error) {
    sendError(client, "Invalid JSON");
    return;
  }

  if (String((const char*)doc["type"]) != "command") return;

  String command = String((const char*)doc["command"]);
  lastCommandTime = millis();

  if (command == "PING") {
    sendAck(client, command);
  } else if (command == "SPEED") {
    conversionSpeedPercent = constrain((int)doc["value"], 0, 100);
    sendAck(client, command);
  } else if (command == "EMERGENCY_STOP") {
    emergencyActive = true;
    conversionMotorStop();
    conversionState = "STOPPED";
    sendAck(client, command);
  } else if (command == "RESET_EMERGENCY") {
    emergencyActive = false;
    conversionMotorStop();
    conversionState = "STOPPED";
    sendAck(client, command);
  } else if (command == "CONVERT_STOP") {
    conversionMotorStop();
    conversionState = "STOPPED";
    sendAck(client, command);
  } else if (!emergencyActive && CONVERSION_MOTOR_ENABLED && command == "CONVERT_WHEELCHAIR_START") {
    conversionMotorForward();
    conversionState = "CONVERTING";
    sendAck(client, command);
  } else if (!emergencyActive && CONVERSION_MOTOR_ENABLED && command == "CONVERT_BED_START") {
    conversionMotorReverse();
    conversionState = "RETURNING";
    sendAck(client, command);
  } else {
    conversionMotorStop();
    sendError(client, "Command blocked or unsupported");
  }
}

void enforceCommandWatchdog() {
  bool motorRunning = conversionState == "CONVERTING" || conversionState == "RETURNING";
  if (motorRunning && millis() - lastCommandTime > COMMAND_TIMEOUT_MS) {
    conversionMotorStop();
    conversionState = "STOPPED";
  }
}

void conversionMotorForward() {
  if (emergencyActive) {
    conversionMotorStop();
    return;
  }

  digitalWrite(CONV_REN_PIN, HIGH);
  digitalWrite(CONV_LEN_PIN, HIGH);
  uint8_t pwm = map(conversionSpeedPercent, 0, 100, 0, 255);
  ledcWrite(CONVERSION_MOTOR_INVERTED ? PWM_CHANNEL_L : PWM_CHANNEL_R, pwm);
  ledcWrite(CONVERSION_MOTOR_INVERTED ? PWM_CHANNEL_R : PWM_CHANNEL_L, 0);
}

void conversionMotorReverse() {
  if (emergencyActive) {
    conversionMotorStop();
    return;
  }

  digitalWrite(CONV_REN_PIN, HIGH);
  digitalWrite(CONV_LEN_PIN, HIGH);
  uint8_t pwm = map(conversionSpeedPercent, 0, 100, 0, 255);
  ledcWrite(CONVERSION_MOTOR_INVERTED ? PWM_CHANNEL_R : PWM_CHANNEL_L, pwm);
  ledcWrite(CONVERSION_MOTOR_INVERTED ? PWM_CHANNEL_L : PWM_CHANNEL_R, 0);
}

void conversionMotorStop() {
  ledcWrite(PWM_CHANNEL_R, 0);
  ledcWrite(PWM_CHANNEL_L, 0);
}

void sendTelemetry() {
  StaticJsonDocument<512> doc;
  doc["type"] = "telemetry";

  float heartRate = NAN;
  float spo2 = NAN;
  readMax30102(heartRate, spo2);

  if (isnan(heartRate)) doc["heartRate"] = nullptr;
  else doc["heartRate"] = heartRate;

  if (isnan(spo2)) doc["spo2"] = nullptr;
  else doc["spo2"] = spo2;

  if (mlxReady) {
    doc["bodyTemperature"] = mlx.readObjectTempC();
    doc["ambientTemperature"] = mlx.readAmbientTempC();
  } else {
    doc["bodyTemperature"] = nullptr;
    doc["ambientTemperature"] = nullptr;
  }

  float batteryVoltage = readBatteryVoltage();
  int batteryPercent = estimateBatteryPercent(batteryVoltage);
  doc["batteryVoltage"] = batteryVoltage;
  doc["batteryPercent"] = batteryPercent;
  doc["batteryStatus"] = batteryPercent <= 10 ? "CRITICAL" : batteryPercent < 25 ? "LOW" : "GOOD";
  doc["conversionState"] = conversionState;
  doc["conversionPosition"] = conversionPosition;
  doc["emergency"] = emergencyActive;

  String json;
  serializeJson(doc, json);
  webSocket.broadcastTXT(json);
}

void readMax30102(float &heartRate, float &spo2) {
  if (!maxReady) return;

  const int bufferLength = 100;
  static uint32_t irBuffer[bufferLength];
  static uint32_t redBuffer[bufferLength];
  static uint8_t sampleIndex = 0;
  static float lastValidHeartRate = NAN;
  static float lastValidSpo2 = NAN;

  while (max30102.available()) {
    redBuffer[sampleIndex] = max30102.getRed();
    irBuffer[sampleIndex] = max30102.getIR();
    max30102.nextSample();

    if (irBuffer[sampleIndex] < 50000) {
      lastValidHeartRate = NAN;
      lastValidSpo2 = NAN;
      sampleIndex = 0;
      return;
    }

    sampleIndex++;
    if (sampleIndex >= bufferLength) {
      int32_t calculatedSpo2 = 0;
      int8_t validSpo2 = 0;
      int32_t calculatedHeartRate = 0;
      int8_t validHeartRate = 0;

      maxim_heart_rate_and_oxygen_saturation(
        irBuffer,
        bufferLength,
        redBuffer,
        &calculatedSpo2,
        &validSpo2,
        &calculatedHeartRate,
        &validHeartRate
      );

      if (validHeartRate && calculatedHeartRate > 35 && calculatedHeartRate < 180) {
        lastValidHeartRate = calculatedHeartRate;
      }
      if (validSpo2 && calculatedSpo2 >= 70 && calculatedSpo2 <= 100) {
        lastValidSpo2 = calculatedSpo2;
      }
      sampleIndex = 0;
    }
  }

  max30102.check();
  heartRate = lastValidHeartRate;
  spo2 = lastValidSpo2;
}

float readBatteryVoltage() {
  uint32_t total = 0;
  const int samples = 40;
  for (int i = 0; i < samples; i++) {
    total += analogRead(BATTERY_ADC_PIN);
    delay(2);
  }

  float adc = total / (float)samples;
  float pinVoltage = (adc / ADC_MAX) * ADC_REFERENCE;
  float dividerRatio = (BATTERY_R1 + BATTERY_R2) / BATTERY_R2;
  return pinVoltage * dividerRatio * BATTERY_CALIBRATION;
}

int estimateBatteryPercent(float voltage) {
  const float emptyVoltage = 21.0;
  const float fullVoltage = 25.6;
  return constrain((int)(((voltage - emptyVoltage) / (fullVoltage - emptyVoltage)) * 100.0), 0, 100);
}

void sendAck(uint8_t client, const String &command) {
  StaticJsonDocument<128> doc;
  doc["type"] = "ack";
  doc["command"] = command;
  String json;
  serializeJson(doc, json);
  webSocket.sendTXT(client, json);
}

void sendError(uint8_t client, const String &message) {
  StaticJsonDocument<160> doc;
  doc["type"] = "error";
  doc["message"] = message;
  String json;
  serializeJson(doc, json);
  webSocket.sendTXT(client, json);
}
